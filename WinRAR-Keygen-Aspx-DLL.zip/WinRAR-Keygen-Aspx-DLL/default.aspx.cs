using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Web.UI;

public partial class _Default : Page
{
    [DllImport("C:\\inetpub\\wwwroot\\WinRAR-Generate\\WinRAR-Keygen-Aspx.dll", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
    private static extern IntPtr KeyGenerate(string UserName, string LicenseType);

    protected void Page_Load(object sender, EventArgs e)
    {
        // Đảm bảo trang sử dụng UTF-8
        Response.ContentEncoding = Encoding.UTF8;
        Response.Charset = "UTF-8";
    }

    [System.Web.Services.WebMethod]
    public static string GenerateKey(string UserName, string LicenseType)
    {
        if (string.IsNullOrEmpty(UserName))
        {
            return "Please enter the username.";
        }

        if (string.IsNullOrEmpty(LicenseType))
        {
            return "Please enter the license type.";
        }

        try
        {
            IntPtr keyPtr = KeyGenerate(UserName, LicenseType);
            return Marshal.PtrToStringAnsi(keyPtr);
        }
        catch (Exception ex)
        {
            return "An error occurred: " + ex.Message;
        }
    }
}
